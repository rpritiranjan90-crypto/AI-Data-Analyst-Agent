"""
Application exceptions package.
"""