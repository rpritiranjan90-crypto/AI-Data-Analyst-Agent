"""
Common utilities package.
"""